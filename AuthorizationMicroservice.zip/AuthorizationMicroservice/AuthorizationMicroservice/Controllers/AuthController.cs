﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using AuthorizationMicroservice.Services;
using Microsoft.AspNetCore.Http;

namespace AuthorizationMicroservice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuth _auth;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly log4net.ILog _log4net;
        public AuthController(IAuth auth, SignInManager<IdentityUser> signInManager, UserManager<IdentityUser> userManager)
        {
            _auth = auth;
            _signInManager = signInManager;
            _userManager = userManager;
            _log4net = log4net.LogManager.GetLogger(typeof(AuthController));
        }

        [HttpPost, Route("/auth")]
        public async Task<IActionResult> Post(string email,string password)
        {
            _log4net.Info(" Http POST request For Login in " + nameof(AuthController));
            try
            {
                var result = await _signInManager.PasswordSignInAsync(email, password, false, false);
                if (!result.Succeeded)
                {
                    _log4net.Error(" Email and Password not matched in " + nameof(AuthController));
                    return Unauthorized(new { Error = "Email and Password not matched." });
                }


                var token = _auth.GenerateJSONWebToken(email, password);

                return Ok(new { token });
            }
            catch (Exception ex)
            {
                _log4net.Error(" Email and Password not matched in " + nameof(AuthController));
                return Unauthorized(new { Error = "Email and Password not matched." });
            }
        }

        [HttpPost]
        [Route("/SignUp")]
        public async Task<IActionResult> SignUp(string email, string password)
        {
            _log4net.Info(" Http POST request For SignUp in " + nameof(AuthController));
            if (ModelState.IsValid)
            {
                var user = new IdentityUser { UserName = email, Email = email};
                var result = await _userManager.CreateAsync(user, password);

                if (result.Succeeded)
                {
                    return Ok();
                }

                var err = new List<String>();
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                    err.Add(error.Description);
                }
                _log4net.Error(" Exception Here " + err + " in " + nameof(AuthController));
                return BadRequest(err);
            }

            return BadRequest("Error");
        }
    }
}
