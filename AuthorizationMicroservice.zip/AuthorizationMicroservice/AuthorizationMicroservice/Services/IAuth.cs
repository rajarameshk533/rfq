﻿using Microsoft.AspNetCore.Mvc;

namespace AuthorizationMicroservice.Services
{
    public interface IAuth
    {
        string GenerateJSONWebToken(string email, string password);
    }
}
