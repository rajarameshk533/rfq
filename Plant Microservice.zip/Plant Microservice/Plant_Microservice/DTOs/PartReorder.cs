﻿
namespace Plant_Microservice.DTOs
{
    public class PartReorder
    {
        public int Id { get; set; }

        public string PartDetails { get; set; }

        public string Description { get; set; }

        public string PartSpecification { get; set; }

        public int StockInHand { get; set; }

        public int Min { get; set; }

        public int Max { get; set; }

        public int Needs { get; set; }

        public int DemandId { get; set; }

        public PartReorder(int id, string partDetails, string description, string partSpecification, int stockInHand, int min, int max, int needs, int demandId)
        {
            Id = id;
            PartDetails = partDetails;
            Description = description;
            PartSpecification = partSpecification;
            StockInHand = stockInHand;
            Min = min;
            Max = max;
            Needs = needs;
            DemandId = demandId;    
        }
    }
}
