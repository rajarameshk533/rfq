﻿using Microsoft.AspNetCore.Mvc;
using Plant_Microservice.Models;
using Plant_Microservice.DTOs;

namespace Plant_Microservice.Repository
{
    public interface IPlantService
    {
        public List<PartReorder> viewPartsReOrder();

        public int viewStockInHand(int partId);

        public bool updateMinMaxQuantities(int partId, int minQuantity, int maxQuantity);
    }
}