﻿using Microsoft.AspNetCore.Mvc;
using Plant_Microservice.Models;
using Plant_Microservice.DTOs;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace Plant_Microservice.Repository
{
    public class PlantService : IPlantService
    {
        private readonly PlantDBContext _context;

        public PlantService(PlantDBContext context)
        {
            _context = context;
        }

        public List<PartReorder> viewPartsReOrder()
        {

            var partList = _context.Parts.Where(p => p.Demands != null && p.Demands.Any(d=>d.Status==0) &&
                                                p.ReorderRule.Min > p.StockInHand)
                                         .Include(p => p.ReorderRule).Include(p=>p.Demands).ToList();

            var partReorders = new List<PartReorder>();
            foreach (var part in partList)
            {
                int needs = part.ReorderRule.Max - part.ReorderRule.Min;
                var partReorder = new PartReorder(
                                      part.Id, part.PartDetails, part.Description, part.PartSpecification, part.StockInHand,
                                      part.ReorderRule.Min, part.ReorderRule.Max, needs,
                                      part.Demands.First(d => d.Status == 0).Id
                                   );
                partReorders.Add(partReorder);

                if(!_context.PlantReorderDetails.Any(p=>p.DemandId==partReorder.DemandId))
                {
                    PlantReorderDetail plantReorderDetail = new PlantReorderDetail
                    {
                        PartID = part.Id,
                        Part = part,
                        DemandId = partReorder.DemandId,
                        Date = DateTime.Now,
                    };
                    _context.PlantReorderDetails.Add(plantReorderDetail);
                    _context.SaveChanges();
                }
            }

            return partReorders;
        }

        public int viewStockInHand(int partId)
        {
            var part = _context.Parts.SingleOrDefault(p => p.Id == partId);
            if (part == null)
                return 0;

            return part.StockInHand;
        }

        public bool updateMinMaxQuantities(int partId, int minQuantity, int maxQuantity)
        {
            int lb = maxQuantity * 30 / 100;
            int ub = maxQuantity * 50 / 100;
            if (minQuantity < lb || minQuantity > ub)
                return false;

            int demand = 0;
            var demandPart = _context.Demands.SingleOrDefault(d => d.PartID == partId && d.Status==0);
            if (demandPart!=null)
                demand = demandPart.Quantity;


            if ((demand + demand * 20 / 100) < maxQuantity)
                return false;

            var partRule = _context.ReorderRules.SingleOrDefault(p => p.PartId == partId);

            if (partRule == null)
                return false;

            partRule.Min = minQuantity;
            partRule.Max = maxQuantity;
            _context.SaveChanges();

            return true;
        }
    }
}
