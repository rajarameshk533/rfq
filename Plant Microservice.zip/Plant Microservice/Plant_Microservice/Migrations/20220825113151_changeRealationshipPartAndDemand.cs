﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Plant_Microservice.Migrations
{
    public partial class changeRealationshipPartAndDemand : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Demands_PartID",
                table: "Demands");

            migrationBuilder.AddColumn<int>(
                name: "Status",
                table: "Demands",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Demands_PartID",
                table: "Demands",
                column: "PartID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Demands_PartID",
                table: "Demands");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "Demands");

            migrationBuilder.CreateIndex(
                name: "IX_Demands_PartID",
                table: "Demands",
                column: "PartID",
                unique: true);
        }
    }
}
