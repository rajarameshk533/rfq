﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Plant_Microservice.Migrations
{
    public partial class changeRealationshipDemandAndPlantReorderDetails : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DemandId",
                table: "PlantReorderDetails",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_PlantReorderDetails_DemandId",
                table: "PlantReorderDetails",
                column: "DemandId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_PlantReorderDetails_Demands_DemandId",
                table: "PlantReorderDetails",
                column: "DemandId",
                principalTable: "Demands",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PlantReorderDetails_Demands_DemandId",
                table: "PlantReorderDetails");

            migrationBuilder.DropIndex(
                name: "IX_PlantReorderDetails_DemandId",
                table: "PlantReorderDetails");

            migrationBuilder.DropColumn(
                name: "DemandId",
                table: "PlantReorderDetails");
        }
    }
}
