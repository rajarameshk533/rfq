﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Plant_Microservice.Migrations
{
    public partial class addRelationshipPartAndDemand : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Demands_PartID",
                table: "Demands");

            migrationBuilder.CreateIndex(
                name: "IX_Demands_PartID",
                table: "Demands",
                column: "PartID",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Demands_PartID",
                table: "Demands");

            migrationBuilder.CreateIndex(
                name: "IX_Demands_PartID",
                table: "Demands",
                column: "PartID");
        }
    }
}
