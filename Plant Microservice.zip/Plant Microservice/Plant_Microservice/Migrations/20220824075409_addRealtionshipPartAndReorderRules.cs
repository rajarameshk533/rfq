﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Plant_Microservice.Migrations
{
    public partial class addRealtionshipPartAndReorderRules : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ReorderRules_PartId",
                table: "ReorderRules");

            migrationBuilder.CreateIndex(
                name: "IX_ReorderRules_PartId",
                table: "ReorderRules",
                column: "PartId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ReorderRules_PartId",
                table: "ReorderRules");

            migrationBuilder.CreateIndex(
                name: "IX_ReorderRules_PartId",
                table: "ReorderRules",
                column: "PartId");
        }
    }
}
