﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Plant_Microservice.Migrations
{
    public partial class renamePartIDtoPartIdinReorderTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReorderRules_Parts_PartID",
                table: "ReorderRules");

            migrationBuilder.RenameColumn(
                name: "PartID",
                table: "ReorderRules",
                newName: "PartId");

            migrationBuilder.RenameIndex(
                name: "IX_ReorderRules_PartID",
                table: "ReorderRules",
                newName: "IX_ReorderRules_PartId");

            migrationBuilder.AddForeignKey(
                name: "FK_ReorderRules_Parts_PartId",
                table: "ReorderRules",
                column: "PartId",
                principalTable: "Parts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReorderRules_Parts_PartId",
                table: "ReorderRules");

            migrationBuilder.RenameColumn(
                name: "PartId",
                table: "ReorderRules",
                newName: "PartID");

            migrationBuilder.RenameIndex(
                name: "IX_ReorderRules_PartId",
                table: "ReorderRules",
                newName: "IX_ReorderRules_PartID");

            migrationBuilder.AddForeignKey(
                name: "FK_ReorderRules_Parts_PartID",
                table: "ReorderRules",
                column: "PartID",
                principalTable: "Parts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
