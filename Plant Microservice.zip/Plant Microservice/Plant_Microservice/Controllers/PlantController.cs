﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Plant_Microservice.Repository;
using Plant_Microservice.Models;
using Plant_Microservice.DTOs;
using Microsoft.AspNetCore.Authorization;

namespace Plant_Microservice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class PlantController : ControllerBase
    {
        IPlantService _plantService;

        public PlantController(IPlantService plantService)
        {
            _plantService = plantService;   
        }

        
        [HttpGet, Route("/viewPartsReOrder")]
        public async Task<ActionResult<IEnumerable<PartReorder>>> viewPartsReOrder()
        {
            var res= _plantService.viewPartsReOrder();
            if (res == null)
                return BadRequest();
            return Ok(res);
        }

        [HttpGet, Route("/viewStockInHand")]
        public async Task<ActionResult<int>> viewStockInHand(int partId)
        {
            int res= _plantService.viewStockInHand(partId);
            if (res == 0)
                return NotFound("No Stocks Found");
            return Ok(res);
        }

        [HttpPost, Route("/updateMinMaxQuantities")]
        public async Task<ActionResult> updateMinMaxQuantities(int partId, int minQuantity, int maxQuantity)
        {
            bool res= _plantService.updateMinMaxQuantities(partId, minQuantity, maxQuantity);
            if(res)
                return Ok(res);
            return BadRequest();

        }
    }
}
