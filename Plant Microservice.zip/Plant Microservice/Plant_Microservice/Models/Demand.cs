﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Plant_Microservice.Models
{
    public class Demand
    {
        public int Id { get; set; }
        
        [Required]
        public DateTime DemandRaiseDate { get; set; }

        public int Status { get; set; } = 0;

        [Required]
        public int Quantity { get; set; }

        public virtual PlantReorderDetail? PlantReorderDetail { get; set; }

        [ForeignKey("Part")]
        public int PartID { get; set; }

        public virtual Part Part { get; set; }
    }
}
