﻿using Microsoft.EntityFrameworkCore;

namespace Plant_Microservice.Models
{
    public class PlantDBContext : DbContext
    {
        public PlantDBContext(DbContextOptions<PlantDBContext> options) : base(options)
        {

        }

        public DbSet<Part> Parts { get; set; }

        public DbSet<Demand> Demands { get; set; }

        public DbSet<ReorderRule> ReorderRules { get; set; }

        public DbSet<PlantReorderDetail> PlantReorderDetails { get; set; }
    }
}


