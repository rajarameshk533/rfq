﻿using System.ComponentModel.DataAnnotations;

namespace Plant_Microservice.Models
{
    public class Part
    {
        public int Id { get; set; }

        [Required]
        public string PartDetails { get; set; }

        public string Description { get; set; }

        public string PartSpecification { get; set; }

        [Required]
        public int StockInHand { get; set; }

        public virtual ICollection<Demand>? Demands { get; set; }

        public virtual ReorderRule ReorderRule { get; set; }

        public virtual ICollection<PlantReorderDetail> PlantReorderDetails { get; set; }

    }
}

