﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Plant_Microservice.Models
{
    public class ReorderRule
    {
        public int Id { get; set; }
        public int Min { get; set; }

        public int Max { get; set; }

        public int ReorderFrequency { get; set; }

        [ForeignKey("Part")]
        public int PartId { get; set; }

        public virtual Part Part { get; set; }
    }
}
