﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Plant_Microservice.Models
{
    public class PlantReorderDetail
    {
        public int Id { get; set; }

        [ForeignKey("Part")]
        public int PartID { get; set; }

        public virtual Part Part { get; set; }

        [ForeignKey("Demand")]
        public int DemandId { get; set; }

        public virtual Demand Demand { get; set; }

        public int Status { get; set; } = 0;

        public DateTime Date { get; set; }

    }
}

