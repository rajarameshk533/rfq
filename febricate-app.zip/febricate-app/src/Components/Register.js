import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Spinner, Button, Card, CardBody, Col, Container, Form, Input, InputGroup, Row } from 'reactstrap';
import { ToastContainer, toast } from "react-toastify";
import './MyStyle.css'
const Register = () => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [pcheck, setPcheck] = useState("");
    const [loaded, setValue] = useState(true);
    const navigate = useNavigate();

    function validate() {
        const namereg = /^(?!\s)[A-Z0-9\s]+$/i;
        if (name === "") {
            toast.warning("Please Enter Name", { position: "top-center" });
            return false;
        }
        if (namereg.test(name) === false) {
            toast.warning("Name should contains letters only", { position: "top-center" });
            return false;
        }
        const emailreg = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
        if (email === "") {
            toast.warning("Email is required", { position: "top-center" });
            return false;
        }
        if (emailreg.test(email) === false) {
            toast.warning("Email is Not Correct", { position: "top-center" });
            return false;
        }
        if (password === "") {
            toast.warning("Password is required", { position: "top-center" });
            return false;
        }
        if (password !== pcheck) {
            toast.warning("Password not Maching", { position: "top-center" });
            return false;
        }
        return true;
    }
    function register() {

        let item = { email, name, password }
        if (validate()) {
            setValue(false);
            fetch('https://localhost:7104/api/register', {
                method: 'POST',
                body: JSON.stringify(item),
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                }
            }).then((response) => {
                if (response.status === 201) {
                    setValue(true);
                    navigate("/login")
                }
                else if (response.status === 409) {
                    setValue(true);
                    alert("User Already Registered");
                }
                else {
                    setValue(true);
                    alert("Please try again");
                }
            }).catch(() => {
                setValue(true);
                toast.error("Server Not Found", { position: "top-center" })
            })
        }
    }
    return (
        <div>
            <ToastContainer />
            <div className="register">
                <div className="flex-row align-items-center">
                    <Container>
                        <Row className="justify-content-center">
                            <Col md="9" lg="7" xl="6">
                                <Card className="p-2 border-warning border-2 bg-dark">
                                    <CardBody>
                                        <Form>
                                            <div className="row mb-2 pageheading">
                                                <h2 className="text-light">SignUp</h2>
                                                {loaded === false && <div>
                                                    <Spinner role="status" color="info" /></div>}
                                            </div>
                                            <InputGroup className="mb-3">
                                                <Input className="w-100" type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter Full Name" />
                                            </InputGroup>
                                            <InputGroup className="mb-3">
                                                <Input className="w-100" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter Email" />
                                            </InputGroup>
                                            <InputGroup className="mb-3">
                                                <Input className="w-100" maxLength={15} type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter Password" />
                                            </InputGroup>
                                            <InputGroup className="mb-3">
                                                <Input className="w-100" maxLength={15} type="password" value={pcheck} onChange={(e) => setPcheck(e.target.value)} placeholder="Confirm Password" />
                                            </InputGroup>
                                            <InputGroup className="mb-1">
                                                <Button onClick={register} color="success" block>Create Account</Button>
                                            </InputGroup>
                                            <InputGroup className="mb-1">
                                                <Button onClick={() => navigate("/")} color="warning" block>Back To Home</Button>
                                            </InputGroup>
                                        </Form>
                                    </CardBody>
                                </Card>
                            </Col>
                        </Row>
                    </Container>
                </div>
            </div>
        </div>
    );

}
export default Register;