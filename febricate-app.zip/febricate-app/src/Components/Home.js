import React from "react";
import Navbar from "./Navbar";
import { useNavigate } from "react-router-dom";
import Blink from 'react-blink-text';
import "./MyStyle.css"
//import "bootstrap";
function Home() {
  const navigate = useNavigate();
  return (
    <div><Navbar/>
      <div className="home">
        
        <h2 className="text1">Welcome To RFQ Management Portal</h2>
        <br /><br /><br />
        <Blink color='blue' text='Click Here For Login' fontSize='70' />
        <button className="btn btn-primary custom btn-lg"
          onClick={() => navigate("/login")}>Login</button>
      </div>
      </div>
   );
}

export default Home;