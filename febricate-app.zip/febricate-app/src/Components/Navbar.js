import React from "react";
import { Link } from "react-router-dom";
class Navbar extends React.Component {
    render() {
        return (
            <div className="header">
                <nav className="navbar navbar-expand navbar1 navbar-light">
                    <div className="container-fluid bg-light">
                        <div className="navbar-brand"><h3 >RFQ Management Portal</h3></div>
                        <button className="navbar-toggler " type="button" data-bs-toggle="collapse" data-bs-target="#navbar">
                            <span className="navbar-toggler-icon " ></span></button>

                        <div className="collapse navbar-collapse" id="navbar">
                            <ul className="navbar-nav ms-auto">
                            <li className="nav-item">
                                    <Link to={"/"} className="nav-link text-dark"><h4>Home</h4></Link>
                                </li>
                                <li className="nav-item">
                                    <Link to={"/login"} className="nav-link text-dark"><h4>Login</h4></Link>
                                </li>
                              </ul>
                        </div>
                    </div>
                </nav>
            </div>
        )
    }
}
export default Navbar;