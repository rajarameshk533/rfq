import { Navigate } from 'react-router-dom';
import ManagementRoom from './ManagementRoom';
function Protected(){
   var user=sessionStorage.getItem("auth");
   return(
      <div>{user ?<ManagementRoom/>:<Navigate to="/login"/>}</div>
    )
}
export default Protected;