import {ToastContainer } from "react-toastify";
import { useState } from 'react';
import "../MyStyle.css";
import GetRfqOfPlant from "./GetRfqOfPlant";
import GetPotentialVendor from "./GetPotentialVendor";
function Rfq()
{
    const [value,setValue]=useState(0);
    return (<div className="rfq">
        <ToastContainer />
        <ul className="nav nav-tabs justify-content-center">
            <li className="tab-item ">
                <a className="nav-link show active" onClick={()=>setValue(0)} 
                  data-bs-toggle="tab" href="#add">Get RQF Of Plant</a>
            </li>
            <li className="tab-item">
                <a className="nav-link" onClick={()=>setValue(1)} 
                  data-bs-toggle="tab" href="#view">Get Potential Vendor Of RFQ</a>
            </li>
        </ul>
        <div className="tab-content">
            <div id="add" className="tab-pane fade show active">
                {value===0&&<GetRfqOfPlant/>}
            </div>
            <div id="view" className="tab-pane fade active">
                {value===1&&<GetPotentialVendor/>}
            </div>
        </div>
    </div>)
}
export default Rfq;