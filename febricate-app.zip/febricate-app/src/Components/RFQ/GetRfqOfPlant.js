import { useState } from 'react';
import {
    Button, Card, CardBody, CardGroup, Col, Container,
    Input, InputGroup, Row
} from 'reactstrap';
import { toast } from "react-toastify";
import ShowRFQ from './ShowRFQ';
function GetRfqOfPlant() {
    const [rfq, setRFQ] = useState();
    const [info, setInfo]=useState({id:null,pd:null,des:null,spec:null,quantity:null,ed:null});
    const auth = sessionStorage.getItem("auth");
    const GetRFQ = () => {
        var id = document.getElementById("plantId").value;
        if (id) fetch("https://localhost:5001/gateway/getRFQOfPlant?plantId=" + id, {
            headers: {
                'Authorization': 'Bearer ' + auth,
                'Content-Type': 'application/json',
                Accept: 'application/json'
            }
        })
            .then((response) => {
                if (response.status === 200) {
                    response.json().then((res) => {
                        setRFQ(res.result);
                        document.getElementById("plantId").value = null;
                        //toast("RQF Details Received", { position: "top-center" });
                    })
                }
                else if (response.status === 401) {
                    toast.warning("Session Expired", { position: "top-center" })
                }
                else if (response.status === 404) {
                    toast.warning("RFQ Not Found", { position: "top-center" })
                }
            }).catch(() => { toast.error("Server Error", { position: "top-center" }) })
        else toast.warning("Please Enter PartId", { position: "top-center" })
    }
    return (
        <div>
            <ShowRFQ info={info}/>
            {rfq ?
            <table className='view'>
            {rfq.map((items) =>
                    <td key={items.id}>
                        <Container className='pt-5'>
                        <Card className='border-dark bg-info' style={{"width": "12rem"}}>
                            <CardBody >
                                <div>RFQ With ID: {items.id}</div>
                                <div> Part Details: {items.partDetails}</div>
                                <Button data-bs-toggle="modal" data-bs-target="#rfq"
                                onClick={()=>setInfo({id:items.id,
                                                      pd:items.partDetails,
                                                      des:items.description,
                                                      spec:items.partSpecification,
                                                      quantity:items.quantity,
                                                      ed:items.expectedSupplyDate})}>View</Button>
                            </CardBody>
                        </Card>
                        </Container>
                        </td>)}
                        </table>
                : <Container className='p-5'>
                    <Row className="justify-content-center">
                        <Col md="9" lg="7" xl="6">
                            <CardGroup>
                                <Card className="p-2 border-dark">
                                    <CardBody>
                                        <div className="row mb-2 pageheading">
                                            <h5>Get RFQ Of Plant</h5>
                                        </div>
                                        <InputGroup className='mb-2'>
                                            <Input type="text" id="plantId" placeholder="Enter Plant ID" />
                                        </InputGroup>
                                        <Button color="success" onClick={GetRFQ}>Submit</Button>
                                    </CardBody>
                                </Card>
                            </CardGroup>
                        </Col>
                    </Row>
                </Container>}
        </div>)
}
export default GetRfqOfPlant;