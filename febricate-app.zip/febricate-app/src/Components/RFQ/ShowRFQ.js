import "../MyStyle.css"
const ShowRFQ = (props) => {
    const details={id:props.info.id,title:props.info.pd+" RFQ",pd:props.info.pd,
                   des:props.info.des,spec:props.info.spec,
                   quantity:props.info.quantity,ed:props.info.ed};
    let newDate = new Date()
    let date = newDate.getDate();
    let month = newDate.getMonth() + 1;
    let year = newDate.getFullYear();
    return (
        <div className="modal fade" id="rfq" data-bs-backdrop="static" tabindex="-1" aria-labelledby="rfq" aria-hidden="true">
            <div className="modal-dialog modal-xl modal-dialog-centered">
                <div className="modal-content border-info border-2">
                    <div className="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">
                        <div className="flex-row align-items-center">
                            <table className="table table-bordered">
                                <tbody className="border-dark">
                                    <tr>
                                        <th colspan="4" className="text-center text-light h3 bg-dark"> <b>REQUEST FOR QUOTATION</b> </th>
                                    </tr>
                                    <tr>
                                        <th colspan="4" className="h5 text-light bg-secondary"> BUYER DETAILS </th>
                                    </tr>
                                    <tr className="h6">
                                        <td colSpan="2"> NAME OF COMPANY </td>
                                        <td> RFQ TITLE </td>
                                        <td> RFQ ID </td>
                                    </tr>
                                    <tr>
                                        <td colSpan="2"> ABC Manufacturing Plant </td>
                                        <td width="25%">{details.title} </td>
                                        <td>{details.id} </td>
                                    </tr>
                                    <tr>
                                        <td> BUSINESS OVERVIEW </td>
                                        <td colspan="3">Manufacturing CPU, Laptop, Display, Computer </td>
                                    </tr>
                                    <tr className="h6">
                                        <td rowSpan="2" >COMPANY CONTACT DETAILS</td>
                                        <td colSpan="2"> EMAIL ID </td>
                                        <td> CONTACT NUMBER </td>
                                    </tr>
                                    <tr>
                                        <td colSpan="2">abc.manufacturing@gmail.com </td>
                                        <td>9876543210 </td>
                                    </tr>
                                    <tr>
                                        <td> DATE OF RFQ ISSUE </td>
                                        <td colspan="3">{year}-0{month}-0{date} </td>
                                    </tr>
                                    <tr>
                                        <td> PROPOSAL DEADLINE </td>
                                        <td colspan="3">{details.ed} </td>
                                    </tr>

                                    <tr>
                                        <th colspan="4" className="text-light h5 bg-secondary"> RFQ DOCUMENTATION </th>
                                    </tr>
                                    <tr>
                                        <td> PARTS DETAILS </td>
                                        <td colspan="3">{details.pd} </td>
                                    </tr>
                                    <tr>
                                        <td> PARTS DESCRIPTIONS </td>
                                        <td colspan="3">{details.des} </td>
                                    </tr>
                                    <tr>
                                        <td> PARTS SPECIFICATIONS </td>
                                        <td colspan="3">{details.spec} </td>
                                    </tr>
                                    <tr>
                                        <td> QUANTITY NEEDED </td>
                                        <td colspan="3">{details.quantity} </td>
                                    </tr>

                                    <tr>
                                        <td colspan="4" className="text-center text-danger"> * Potential Vendors Should Have Feedback More Than 7. </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>)
}
export default ShowRFQ;