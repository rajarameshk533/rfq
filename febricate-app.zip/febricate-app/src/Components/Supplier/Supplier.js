
import AddSupplier from './AddSupplier';
import ViewSupplier from './ViewSupplier';
import EditSupplier from './EditSupplier';
import UpdateFeedback from './UpdateFeedback';
import {ToastContainer } from "react-toastify";
import { useState } from 'react';
function Supplier() {
    const [value,setValue]=useState(0);
    return (<div className="supplier">
        <ToastContainer />
        <ul class="nav nav-tabs justify-content-center">
            <li class="nav-item ">
                <a class="nav-link active show" onClick={()=>setValue(0)} data-bs-toggle="tab" href="#add">Add Supplier</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onClick={()=>setValue(1)} data-bs-toggle="tab" href="#view">View Supplier</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onClick={()=>setValue(2)} data-bs-toggle="tab" href="#edit">Edit Supplier</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onClick={()=>setValue(3)} data-bs-toggle="tab" href="#update">Update Feedback</a>
            </li>
        </ul>
        <div className="tab-content h-75">
            <div id="add" className="tab-pane fade active show">
                {value===0&&<AddSupplier />}
            </div>
            <div id="view" className="tab-pane fade">
                {value===1&&<ViewSupplier />}
            </div>
            <div id="edit" className="tab-pane fade">
                {value===2&&<EditSupplier />}
            </div>
            <div id="update" className="tab-pane fade">
                {value===3&&<UpdateFeedback />}
            </div>
        </div>
    </div>)
}
export default Supplier;