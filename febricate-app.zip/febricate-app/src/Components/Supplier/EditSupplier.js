import {
    Button, Card, CardBody, CardGroup, Col, Container,
    Input, InputGroup, Row, Form
} from 'reactstrap';
import { toast } from "react-toastify";
const EditSupplier = () => {
    
    function edit(e) {
        e.preventDefault();
        var sid = document.getElementById("sid").value;
        var sName = document.getElementById("sname").value;
        var sEmail = document.getElementById("semail").value;
        var sMobile = document.getElementById("smobile").value;
        var sAddress = document.getElementById("address").value;
        var feedback = 0;
        var PartsLink = [];
        const auth=sessionStorage.getItem("auth");
        let item = { sid, sName, sEmail, sMobile, sAddress, feedback, PartsLink };
        fetch("https://localhost:5001/gateway/editsupplier", {
            method: 'POST',
            body: JSON.stringify(item),
            headers: {
                'Authorization': 'Bearer ' + auth,
                'Content-Type': 'application/json',
                Accept: 'application/json'
            }
        }).then((response) => {
            if (response.status === 200) {
                toast.success("Supplier Details Edited Successfullly", { position: "top-center" });
                document.getElementById("sid").value=null;
                document.getElementById("sname").value=null;
                document.getElementById("semail").value=null;
                document.getElementById("smobile").value=null;
                document.getElementById("address").value=null;
            }
            else if(response.status===401){
                toast.warning("Session Expired",{position:"top-center"})
              }
            else if(response.status===404){
                toast.error("Enter Correct Supplier ID", { position: "top-center" }); 
            }
        }).catch(() => {toast.error("Server Error", { position: "top-center" })})
}
    return (<div>
        <Container className='p-5'>
            <Row className="justify-content-center">
                <Col md="9" lg="7" xl="6">
                    <CardGroup>
                        <Card className="p-2 border-dark">
                            <CardBody>
                                <Form onSubmit={edit}>
                                    <div className="row mb-2 pageheading">
                                        <h4>Enter Details For Edit</h4>
                                    </div>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="text" id="sid" placeholder="Enter Supplier ID" required />
                                    </InputGroup>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="text" id="sname" placeholder="Enter Name" required />
                                    </InputGroup>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="email" id="semail" placeholder="Enter Email" required />
                                    </InputGroup>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="number" id="smobile" placeholder="Enter Mobile Number" required />
                                    </InputGroup>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="textarea" id="address" placeholder="Enter Address" required />
                                    </InputGroup>
                                    <InputGroup className="mb-1 justify-content-end">
                                        <Button type="submit" color="success">Submit</Button>
                                    </InputGroup>
                                </Form>
                            </CardBody>
                        </Card>
                    </CardGroup>
                </Col>
            </Row>
        </Container>
    </div>)
}
export default EditSupplier;