import {
    Button, Card, CardBody, CardGroup, Col, Container,
    Input, InputGroup, Row, Form
} from 'reactstrap';
import { toast } from "react-toastify";
const UpdateFeedback = () => {
    //const [suppliers, setSuppliers] = useState();
  const auth=sessionStorage.getItem("auth");
    function update(e) {
        e.preventDefault();
        //const auth=sessionStorage.getItem("auth");
        var sid = document.getElementById("sid").value;
        var feedback = document.getElementById("feedback").value;
        fetch("https://localhost:5001/gateway/updatefeedback?feedback=" + feedback, {
                method: 'POST',
                body: JSON.stringify(sid),
                headers: {
                    'Authorization': 'Bearer ' + auth,
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                }
            }).then((response) => {
                if (response.status === 200) {
                    toast.success("Feedback Updated Successfullly", { position: "top-center" });
                    document.getElementById("sid").value=null;
                    document.getElementById("feedback").value=null;
                }
                if(response.status===404){
                    toast.warning("Supplier ID Not Found", { position: "top-center" });
                }
                else if(response.status===401){
                    toast.warning("Session Expired",{position:"top-center"})
                  }
             }).catch(() => {toast.error("Server Error", { position: "top-center" })
        })
        
    }
    return (<div>
        <Container className='p-5'>
            <Row className="justify-content-center">
                <Col md="9" lg="7" xl="6">
                    <CardGroup>
                        <Card className="p-2 border-dark">
                            <CardBody>
                                <Form onSubmit={update}>
                                    <div className="row mb-2 pageheading">
                                        <h4>Update Feedback</h4>
                                    </div>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="text" id="sid" 
                                              placeholder="Enter Supplier ID" required/>
                                    </InputGroup>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="number" id="feedback" 
                                           placeholder="Enter Feedback" required/>
                                    </InputGroup>
                                    <InputGroup className="mb-1 justify-content-end">
                                        <Button color="success" type='submit'>Submit</Button>
                                    </InputGroup>
                                </Form>
                            </CardBody>
                        </Card>
                    </CardGroup>
                </Col>
            </Row>
        </Container>
    </div>)
}
export default UpdateFeedback;