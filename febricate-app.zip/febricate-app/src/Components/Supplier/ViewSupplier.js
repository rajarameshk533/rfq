import { useState } from 'react';
import {
  Button, Card, CardBody, CardGroup, Col, Container,
  Input, InputGroup, Row,Form
} from 'reactstrap';
import { toast } from "react-toastify";
import "../MyStyle.css";
function ViewSupplier() {
  const [suppliers, setSuppliers] = useState();
  const auth = sessionStorage.getItem("auth");
  const GetSupplier = (e) => {
    e.preventDefault();
    var partname = document.getElementById("partname").value;
    if (partname) fetch("https://localhost:5001/gateway/getsupplierofpart?name=" + partname, {
      headers: {
        'Authorization': 'Bearer ' + auth,
        'Content-Type': 'application/json',
        Accept: 'application/json'
      }
    })
      .then((response) => {
        if (response.status === 200) {
          response.json().then((res) => {
            setSuppliers(res);
            //toast("Supplier Details Received", { position: "top-center" });
          })
        }
        else if (response.status === 404) {
          toast.error("Suppliers Not Found", { position: "top-center" })
        }
        else if (response.status === 401) {
          toast.warning("Session Expired", { position: "top-center" })
        }
      }).catch(() => { toast.error("Server Error", { position: "top-center" }) })
    else toast.warning("Please Enter PartId", { position: "top-center" })
  }
  return (
    <div className='viewsupplier'>
        <div class="modal fade" id="supplier" data-bs-backdrop="static" tabIndex="-1" aria-labelledby="supplier" aria-hidden="true">
          <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-info border-2">
              <div class="modal-header text-light bg-secondary">
                <h5 class="modal-title" id="supplier">Available Suppliers</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={()=>setSuppliers(null)}></button>
              </div>
              <div class="modal-body">
                <div className="flex-row align-items-center">
                {suppliers?
                  <table className='table table-bordered'>
                    <tbody className='border-dark'>
                      <tr>
                        <th >Supplier ID</th>
                        <th >Supplier Name</th>
                        <th >Email</th>
                        <th >Mobile</th>
                        <th >Feedback</th>
                      </tr>
                      
                      {suppliers.map((items) =>
                        <tr key={items.sid}>
                          <td>{items.sid}</td>
                          <td>{items.sName}</td>
                          <td>{items.sEmail}</td>
                          <td>{items.sMobile}</td>
                          <td>{items.feedback}</td>
                        </tr>)}
                    </tbody>
                  </table>:<h5>No Records Found</h5>}
                </div>
              </div>
            </div>
          </div>
        </div>
        <Container className='p-5'>
          <Row className="justify-content-center">
            <Col md="9" lg="7" xl="6">
              <CardGroup>
                <Card className="p-2 border-dark">
                  <CardBody><Form onSubmit={GetSupplier}>
                    <InputGroup className='mb-2'>
                      <Input type="text" id="partname" placeholder="Enter Part Name" required />
                    </InputGroup>
                    <Button color="success" data-bs-toggle="modal"
                      data-bs-target="#supplier" type='submit'>View Supplier</Button>
                  </Form></CardBody>
                </Card>
              </CardGroup>
            </Col>
          </Row>
        </Container>
    </div>)
}
export default ViewSupplier;