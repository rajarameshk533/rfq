import { useState } from 'react';
import {
    Button, Card, CardBody, CardGroup, Col, Container,
    Input, InputGroup, Row, Form
} from 'reactstrap';
import { toast } from "react-toastify";
const AddSupplier = () => {
    const [sid, setSID] = useState(null);
    const [sname, setName] = useState(null);
    const [semail, setEmail] = useState(null);
    const [smobile, setMobile] = useState(null);
    const [saddress, setAddress] = useState(null);
    const [pid, setPID] = useState(null);
    const [pname, setPname] = useState(null);
    const [pquantity, setQuantity] = useState(null);
    const [pdate, setDate] = useState(null);
    const [value, setValue] = useState(false);
    const auth=sessionStorage.getItem("auth");
    function handleSubmit(e) {
        //let supplier={sid,sname,semail,smobile,saddress};
        //console.log(supplier);
        e.preventDefault();

        if (value === false) {
            document.getElementById("sid").value = null;
            document.getElementById("sname").value = null;
            setValue(true);
        }
        else {
            var PartsLink = [], suppliersLink = [], feedback = null;
            let supplier = { sid, sname, semail, smobile, saddress, feedback, PartsLink };
            let supplier_part = { pid, pname, pquantity, pdate, suppliersLink };

            let item = { sid, pid, supplier, supplier_part }
            console.log(item);
            //console.log(supplier_part);
            fetch("https://localhost:5001/gateway/addsupplier", {
                method: 'POST',
                body: JSON.stringify(item),
                headers: {
                    'Authorization': 'Bearer ' + auth,
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                }
            }).then((response) => {
                if (response.status === 200) {
                    toast.success("Supplier Added Successfullly", { position: "top-center" });

                }
                else if(response.status===401){
                    toast.warning("Session Expired", { position: "top-center" });
                }
                else if (response.status === 409) {
                    toast.error("Supplier Already Present", { position: "top-center" });
                }
                //else toast.error("Enter Correct Supplier ID", { position: "top-center" });
            }).catch(() => { toast.error("Server Error", { position: "top-center" }) })
        }
    }
    return (<div>
        <Container className='p-5'>
            <Row className="justify-content-center">
                <Col md="9" lg="7" xl="6">
                    <CardGroup>
                        <Card className="p-2 border-dark">
                            <CardBody>
                                {value ? <Form onSubmit={handleSubmit}>
                                    <div className="row mb-2 pageheading">
                                        <h5>Enter Part Details</h5>
                                    </div>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="text" id="pid" placeholder="Enter Part ID"
                                            onChange={(e) => setPID(e.target.value)} required />
                                    </InputGroup>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="text" id="pname" placeholder="Enter Part Name"
                                            onChange={(e) => setPname(e.target.value)} required />
                                    </InputGroup>
                                    <InputGroup className="mb-3">
                                        <Input className="w-100" type="number" placeholder="Enter Quantity"
                                            onChange={(e) => setQuantity(e.target.value)} required />
                                    </InputGroup>
                                    <InputGroup className="mb-3 justify-content-between">
                                        <span>Enter Date</span>
                                        <span><Input type="date" onChange={(e) => setDate(e.target.value)} required /></span>
                                    </InputGroup>
                                    <InputGroup className="mb-1 justify-content-end">
                                        <Button color="success" type='submit'>Submit</Button>
                                    </InputGroup>
                                </Form>
                                    : <Form onSubmit={handleSubmit}>
                                        <div className="row mb-2 pageheading">
                                            <h5>Enter Supplier Details</h5>
                                        </div>
                                        <InputGroup className="mb-3">
                                            <Input className="w-100" type="text" placeholder="Enter Supplier ID"
                                                id="sid" onChange={(e) => setSID(e.target.value)} required />
                                        </InputGroup>
                                        <InputGroup className="mb-3">
                                            <Input className="w-100" type="text" placeholder="Enter Name"
                                                id="sname" onChange={(e) => setName(e.target.value)} required />
                                        </InputGroup>
                                        <InputGroup className="mb-3">
                                            <Input className="w-100" type="email" placeholder="Enter Email"
                                                onChange={(e) => setEmail(e.target.value)} required />
                                        </InputGroup>
                                        <InputGroup className="mb-3">
                                            <Input className="w-100" type="number" placeholder="Enter Mobile Number"
                                                onChange={(e) => setMobile(e.target.value)} required />
                                        </InputGroup>
                                        <InputGroup className="mb-3">
                                            <Input className="w-100" type="textarea" placeholder="Enter Address"
                                                onChange={(e) => setAddress(e.target.value)} required />
                                        </InputGroup>
                                        <InputGroup className="mb-1 justify-content-end">
                                            <Button color="success">Submit</Button>
                                        </InputGroup>
                                    </Form>}
                            </CardBody>
                        </Card>
                    </CardGroup>
                </Col>
            </Row>
        </Container>
    </div>)
}
export default AddSupplier;