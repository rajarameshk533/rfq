import { useState } from 'react';
import { Button, Card, CardBody, CardGroup, Col, Container, Row } from 'reactstrap';
import { toast } from "react-toastify";
import "../MyStyle.css";
function ViewPartsReorder() {
    const [reorders, setReorders] = useState();
    const auth = sessionStorage.getItem("auth");

    const ViewReorder = () => {
        fetch("https://localhost:5001/gateway/viewPartsReOrder", {
            headers: {
                'Authorization': 'Bearer ' + auth,
                'Content-Type': 'application/json',
                Accept: 'application/json'
            }
        })
            .then((response) => {
                if (response.status === 200) {
                    response.json().then((res) => {
                        setReorders(res);
                        //toast("Reorder Details Received", { position: "top-center" });
                    })
                }
                else if (response.status === 401) {
                    toast.warning("Session Expired", { position: "top-center" })
                }
                else if (response.status === 400) {
                    toast.warning("No ReOrders Found", { position: "top-center" })
                }
            }).catch(() => { toast.error("Server Error", { position: "top-center" }) })
    }
    return (<div>
        <div class="modal fade" id="reorder" data-bs-backdrop="static" tabIndex="-1" aria-labelledby="reorder" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content border-info border-2">
                        <div class="modal-header text-light bg-secondary">
                            <h5 class="modal-title" id="reorder">View Parts Reorder</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={()=>setReorders(null)}></button>
                        </div>
                        <div class="modal-body">
                            <div className="flex-row align-items-center">
                            {reorders ?
                                <table className='table table-bordered'>
                                    <tbody className="border-dark">
                                        <tr>
                                            <th >Part ID</th>
                                            <th >Part Name</th>
                                            <th >Description</th>
                                            <th >Specification</th>
                                            <th >Stock In Hand</th>
                                            <th >Min</th>
                                            <th >Max</th>
                                            <th >Needs</th>
                                            <th >Demand ID</th>
                                        </tr>
                                        {reorders.map((items) =>
                                            <tr key={items.id}>
                                                <td>{items.id}</td>
                                                <td>{items.partDetails}</td>
                                                <td>{items.description}</td>
                                                <td>{items.partSpecification}</td>
                                                <td>{items.stockInHand}</td>
                                                <td>{items.min}</td>
                                                <td>{items.max}</td>
                                                <td>{items.needs}</td>
                                                <td>{items.demandId}</td>
                                            </tr>)}
                                    </tbody>
                                </table>:null}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Container className='p-5'>
                <Row className="justify-content-center">
                    <Col md="9" lg="7" xl="6">
                        <CardGroup>
                            <Card className="p-2 border-dark">
                                <CardBody>
                                    <div className="row mb-2 pageheading">
                                        <h5>View Part Reorder</h5>
                                    </div>
                                    <Button color="primary" data-bs-toggle="modal"
                                    data-bs-target="#reorder" onClick={ViewReorder}>View Reorder</Button>
                                </CardBody>
                            </Card>
                        </CardGroup>
                    </Col>
                </Row>
            </Container>
    </div>)
}
export default ViewPartsReorder;