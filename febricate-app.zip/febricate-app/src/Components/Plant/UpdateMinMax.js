import {
    Button, Card, CardBody, CardGroup, Col, Container,
    Input, InputGroup, Row
} from 'reactstrap';
import { toast } from "react-toastify";
function UpadteMinMax() {
    function update() {
        var id = document.getElementById("pid").value;
        var max = document.getElementById("max").value;
        var min = document.getElementById("min").value;
        const auth=sessionStorage.getItem("auth");
        if (id) {
            fetch("https://localhost:5001/gateway/updateMinMaxQuantities?partId="+id+"&minQuantity="+min+"&maxQuantity="+max, {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + auth,
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                }
            }).then((response) => {
                if (response.status === 200) {
                    toast.success("Min Max Updated Successfullly", { position: "top-center" });
                    document.getElementById("pid").value=null;
                    document.getElementById("max").value=null;
                    document.getElementById("min").value=null;
                }
                else if(response.status===400){
                    toast.error("Incorrect Details", { position: "top-center" });
                }
                else if(response.status===401){
                    toast.warning("Session Expired",{position:"top-center"})
                  }
            }).catch(() => {toast.error("Server Error", { position: "top-center" })})
        }
        else toast.warning("Enter Required Details",{position:"top-center"})
    }
    return (<div>
        <Container className='p-5'>
            <Row className="justify-content-center">
                <Col md="9" lg="7" xl="6">
                    <CardGroup>
                        <Card className="p-2 border-dark">
                            <CardBody>
                                <div className="row mb-2 pageheading">
                                    <h5>Update Min Max</h5>
                                </div>
                                <InputGroup className='mb-2'>
                                    <Input type="number" id="pid" placeholder="Enter Part ID" />
                                </InputGroup>
                                <InputGroup className='mb-2'>
                                    <Input type="number" id="max" placeholder="Enter Maximum Quantity" />
                                </InputGroup>
                                <InputGroup className='mb-2'>
                                    <Input type="number" id="min" placeholder="Enter Minimum Quantity" />
                                </InputGroup>
                                <Button color="success" onClick={update}>Update</Button>
                            </CardBody>
                        </Card>
                    </CardGroup>
                </Col>
            </Row>
        </Container>
    </div>)
}
export default UpadteMinMax;