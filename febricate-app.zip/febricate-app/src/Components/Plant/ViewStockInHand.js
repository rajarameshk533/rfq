import { useState } from 'react';
import {
    Button, Card, CardBody, CardGroup, Col, Container,
    Input, InputGroup, Row
} from 'reactstrap';
import { toast } from "react-toastify";
function ViewStockInHand() {
    const [stocks, setStocks] = useState();
    const auth=sessionStorage.getItem("auth");
    const GetStock = () => {
        var partId = document.getElementById("partId").value;
        if (partId) fetch("https://localhost:5001/gateway/viewStockInHand?partId=" + partId,{
            headers: {
                'Authorization': 'Bearer ' + auth,
                'Content-Type': 'application/json',
                Accept: 'application/json'
            }
        }).then((response) => {
            if (response.status === 200) {
              response.json().then((res) => {
                setStocks(res);
                //toast("Stock Details Received", { position: "top-center" });
              })
            }
            else if(response.status===401){
                toast.warning("Session Expired",{position:"top-center"})
              }
            else if(response.status===404){
                toast.warning("No Stocks Found", { position: "top-center" });
            }
          }).catch(() => {toast.error("Server Error", { position: "top-center" })})
        else toast.warning("Please Enter PartId", { position: "top-center" })
      }
    return (<div>
        
        <div class="modal fade" id="stock" data-bs-backdrop="static" tabIndex="-1" aria-labelledby="stock" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content border-info border-2">
            <div class="modal-header text-light bg-secondary">
              <h5 class="modal-title" id="stock">Stocks</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={()=>setStocks(null)}></button>
            </div>
            <div class="modal-body">
              <div className="flex-row align-items-center">
              <h5>In Hand Stock is {stocks}</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Container className='p-5'>
            <Row className="justify-content-center">
                <Col md="9" lg="7" xl="6">
                    <CardGroup>
                        <Card className="p-2 border-dark">
                            <CardBody>
                                <div className="row mb-2 pageheading">
                                    <h5>View Stock In Hand</h5>
                                </div>
                                <InputGroup className='mb-2'>
                                    <Input type="text" id="partId" placeholder="Enter Part ID" />
                                </InputGroup>
                                <Button color="success" data-bs-toggle="modal"
                                    data-bs-target="#stock" onClick={GetStock}>View Stock</Button>
                            </CardBody>
                        </Card>
                    </CardGroup>
                </Col>
            </Row>
        </Container>
    </div>)
}
export default ViewStockInHand;