import {ToastContainer } from "react-toastify";
import { useState } from 'react';
import ViewPartsReorder from './ViewPartsReorder';
import ViewStockInHand from './ViewStockInHand';
import UpadteMinMax from './UpdateMinMax';
function Plant()
{
    const [value,setValue]=useState(0);
    return (<div className="plant">
        <ToastContainer/>
        <ul class="nav nav-tabs justify-content-center">
            <li class="nav-item ">
                <a class="nav-link show active" onClick={()=>setValue(0)} data-bs-toggle="tab" href="#add">View Parts Reorder</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" onClick={()=>setValue(1)} data-bs-toggle="tab" href="#view">View Stock In Hand</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onClick={()=>setValue(2)} data-bs-toggle="tab" href="#edit">Update Min Max Quantities</a>
            </li>
        </ul>
        <div className="tab-content">
            <div id="add" className="tab-pane fade show active">
                {value===0&&<ViewPartsReorder/>}
            </div>
            <div id="view" className="tab-pane fade">
                {value===1&&<ViewStockInHand/>}
            </div>
            <div id="edit" className="tab-pane fade">
                {value===2&&<UpadteMinMax/>}
            </div>
        </div>
    </div>)
}
export default Plant;

