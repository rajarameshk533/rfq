import React, {useState} from "react";
import {toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import {Card, Container, Input, InputGroup } from 'reactstrap';
const ForgotPassword = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [otp1, setOtp1] = useState("");
    const [otp, setOtp] = useState("");
    const [password, setPass] = useState("");
    const [confirmPass, setCPass] = useState("");
    const [verified,setVerify]=useState(false);
    const name = "";

    const SendOTP = () => {
        let item = { email, name, password }
        fetch('https://localhost:7104/api/verifyotp', {
            method: 'POST',
            body: JSON.stringify(item),
            headers: {
                'Authorization': 'Bearer ',
                'Content-Type': 'application/json',
                Accept: 'application/json'
            }
        }).then((response) => response.json())
            .then((result) => {
                setOtp(result);
            });
    }
    const VerifyOTP=()=>{
        if(otp===otp1) {
            const customMsg = () => (
                <div>OTP Validated Successfully</div>
            )
            toast(customMsg, {
                position: "top-center"
                //autoClose: false,
                //closeButton: false
            })
            setVerify(true);
        }
        else alert("Wrong OTP");
    }
    const ResetPassword = () => {
        if (password === confirmPass) {
            let item = { email, name, password }
            fetch('https://localhost:7104/api/resetpass', {
                method: 'PUT',
                body: JSON.stringify(item),
                headers: {
                    'Authorization': 'Bearer ',
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                }
            }).then((response) => {
                if (response.status === 200) {
                    alert("Password Successfully Created")
                    navigate("/login")
                }
            })
        }
        else alert("Password not Maching")
    }
    const  close=()=>{
        setEmail("");
        setOtp("");
        setOtp1("");
        setPass("");
        setVerify(false);
    }
    return (
        <div className="resetPass">
                <div class="modal fade" id="reset" data-bs-backdrop="static" tabindex="-1" aria-labelledby="reset" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content border-warning border-5">
                            <div class="modal-header">
                                <h5 class="modal-title" id="reset">Reset password</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={close}></button>
                            </div>
                            <div class="modal-body">
                                <div className="flex-row align-items-center">
                                    <Container className="justify-content-center">
                                        <Card className="p-4 border-dark">
                                            <InputGroup className="mb-3">
                                                <Input className="w-100" value={email} type="email" onChange={(e)=>setEmail(e.target.value)} placeholder="Enter Email" />
                                            </InputGroup>
                                        </Card>
                                    </Container>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-bs-target="#verify" 
                                data-bs-toggle="modal" data-bs-dismiss="modal" onClick={SendOTP}>Send OTP</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="verify" data-bs-backdrop="static" tabindex="-1" aria-labelledby="verify" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        {!verified?<div class="modal-content border-warning border-5">
                            <div class="modal-header">
                                <h5 class="modal-title" id="verify">Verify OTP</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={close}></button>
                            </div>
                            <div class="modal-body">
                                <div className="flex-row align-items-center">
                                    <Container className="justify-content-center">
                                        <Card className="p-4 border-dark">
                                            <InputGroup className="mb-3">
                                                <Input className="w-100" type="text" value={otp1} onChange={(e)=>setOtp1(e.target.value)} placeholder="Enter OTP" />
                                            </InputGroup>
                                        </Card>
                                    </Container>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" onClick={VerifyOTP}>Validate OTP</button>
                            </div>
                        </div>
                    :<div class="modal-content border-warning border-5">
                            <div class="modal-header">
                                <h5 class="modal-title" id="password">Create New Password</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={close}></button>
                            </div>
                            <div class="modal-body">
                                <div className="flex-row align-items-center">
                                    <Container className="justify-content-center">
                                        <Card className="p-4 border-dark">
                                            <InputGroup className="mb-3">
                                                <Input type="password" value={password} onChange={(e)=>setPass(e.target.value)} placeholder="Enter New Password" />
                                            </InputGroup>
                                            <InputGroup className="mb-3">
                                                <Input type="password" value={confirmPass} onChange={(e)=>setCPass(e.target.value)} placeholder="Confirm Password" />
                                            </InputGroup>
                                        </Card>
                                    </Container>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" onClick={ResetPassword}>Create Password</button>
                            </div>
                        </div>}
                    </div>
                </div>
            </div>
    );
}
export default ForgotPassword;