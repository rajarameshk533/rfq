import React, { Component } from "react";
import "./MyStyle.css";
import { Link} from "react-router-dom";
import Supplier from "./Supplier/Supplier";
import Plant from "./Plant/Plant";
import Rfq from "./RFQ/Rfq";
class ManagementRoom extends Component {
    constructor() {
        super();
        this.state = { val: 0 };
    }
    logout() {
        sessionStorage.clear();
        
    }
    render() {
        return (<div>
            <nav className="navbar navbar-expand navbar-light">
                <div className="container-fluid bg-info">
                    <div className="navbar-brand"><h4>RFQ Management Portal</h4></div>
                    <button className="navbar-toggler " type="button" data-bs-toggle="collapse" data-bs-target="#navbar1">
                        <span className="navbar-toggler-icon" ></span></button>

                    <div className="collapse navbar-collapse" id="navbar1">
                        <ul className="navbar-nav ms-auto">
                            <li className="nav-item p-2">
                                <Link to={""} className="nav-link text-dark"
                                    onClick={() => this.setState({ val: 0 })}><h5> Manage Supplier</h5></Link>
                            </li>
                            <li className="nav-item p-2">
                                <Link to={""} className="nav-link text-dark"
                                    onClick={() => this.setState({ val: 1 })}><h5>Manage Plant</h5></Link>
                            </li>
                            <li className="nav-item p-2">
                                <Link to={""} className="nav-link text-dark"
                                    onClick={() => this.setState({ val: 2 })}><h5>Manage RFQ</h5></Link>
                            </li>
                            <li className="nav-item p-2">
                                <Link to={"/"} className="nav-link text-dark"
                                onClick={this.logout}><h5>Logout</h5></Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            {this.state.val === 0 && <Supplier />}
            {this.state.val === 1 && <Plant />}
            {this.state.val === 2 && <Rfq />}
        </div>)
    }
}
export default ManagementRoom;