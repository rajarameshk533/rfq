import React, { useState } from "react";
import {
    Spinner, Button, Card, CardBody, CardGroup, Col,
    Container, Form, Input, InputGroup, Row
} from 'reactstrap';
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import Navbar from "./Navbar.js";

const Login = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loaded, setValue] = useState(true);

    const login = (e) => {
        e.preventDefault();
        setValue(false);
        fetch("https://localhost:5001/gateway/" +
            "auth?email=" + email + "&password=" + password, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json',
            }
        }).then((response) => {
            if (response.status === 200) {
                response.json().then((res) => {
                    setValue(true);
                    sessionStorage.setItem("auth", res.token);
                    navigate("/managementroom");
                })
            }
            else if (response.status === 401) {
                setValue(true);
                toast.warning("Invalid Email or Password", { position: "top-center" });
            }
            else if (response.status === 400) {
                setValue(true);
                toast.warning("Please Try Again Later", { position: "top-center" });
            }
        }).catch(() => {
            setValue(true);
            toast.error("Server Error", { position: "top-center" })
        })
    }
    return (
        <div>
            <Navbar />
            <ToastContainer />
            <div className="login">
                <Container>
                    <Row className="justify-content-center">
                        <Col md="9" lg="7" xl="6">
                            <CardGroup>
                                <Card className="p-2 border-warning border-2 bg-dark">
                                    <CardBody>
                                        <Form onSubmit={login}>
                                            <div className="row mb-2 pageheading">
                                                <div className="col-sm-12">
                                                    <h2 className="text-light">Login</h2>
                                                    {loaded === false && <div>
                                                        <Spinner color="info" /></div>}
                                                </div>
                                            </div>
                                            <InputGroup className="mb-3">
                                                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter Email" required />
                                            </InputGroup>
                                            <InputGroup className="mb-3">
                                                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter Password" required />
                                            </InputGroup>
                                            <InputGroup className="mb-1">
                                                <Button color="success" type="submit" block>Login</Button>
                                            </InputGroup>
                                            <InputGroup className="mb-1">
                                                <Button onClick={() => navigate("/")} color="warning" block>Back To Home</Button>
                                            </InputGroup>
                                        </Form>
                                    </CardBody>
                                </Card>
                            </CardGroup>
                        </Col>
                    </Row>
                </Container>
            </div>
        </div>
    );
}
export default Login;