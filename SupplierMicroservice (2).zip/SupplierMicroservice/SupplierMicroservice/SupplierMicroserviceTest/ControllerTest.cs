﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using SupplierMicroservice.Controllers;
using SupplierMicroservice.Models;
using SupplierMicroservice.Services;
using System;
using Assert = NUnit.Framework.Assert;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierMicroserviceTest
{
    [TestFixture]
    internal class ControllerTest
    {
        IList<Supplier> supplier1=new List<Supplier>();
        IList<Supplier>? supplier2;
        SupplierPart supplierPart=new SupplierPart();
        [SetUp]
        public void SetUpMethod()
        {
            var suppliers = new Supplier() { SID = "s4", SName = "Vamsi", SEmail = "vamsi@gmail.com", SMobile = 9124785630, SAddress = "Chennai", Feedback = 8 };
            var part = new Supplier_Part() { PID = "p3", PName = "SSD", PQuantity = 8, PDate = new DateTime(2022, 09, 05) };
            supplierPart = new SupplierPart() { SID = "s4", PID = "p3", Supplier = suppliers, Supplier_Part = part };
            supplier1 = new List<Supplier>()
            {
                new Supplier() { SID = "s1", SName = "Sourav", SEmail = "sourav@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 },
                new Supplier() { SID = "s2", SName = "Souvik", SEmail = "souvik@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 7 }
            };
        }
        [Test]
        public void TestControllerAddSupplierForValidInput()
        {
            var suppliers = new Supplier() { SID = "s3", SName = "Hrikdhiman", SEmail = "hrikdhiman@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 9 };
            var part = new Supplier_Part() { PID = "p3", PName = "SSD", PQuantity = 8, PDate = new DateTime(2022, 09, 05) };
            var supplierPart = new SupplierPart() { SID = "s3", PID = "p3", Supplier = suppliers, Supplier_Part = part };
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.AddSupplier(supplierPart)).Returns(true);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.Post(supplierPart) as ObjectResult;
            Assert.AreEqual(200,result.StatusCode );
        }
        [Test]
        public void TestControllerAddSupplierForInvalidInput()
        {
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.AddSupplier(supplierPart)).Returns(false);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.Post(supplierPart) as ObjectResult;
            Assert.AreEqual(409, result.StatusCode);
        }
        [Test]
        public void TestControllerAddSupplierTestForPresentPart()
        {
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.AddSupplier(supplierPart)).Returns(true);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.Post(supplierPart) as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }
        [Test]
        public void TestControllerGetSupplierOfPartTestForValidInput()
        {
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.SupplierOfPart("cpu")).Returns(supplier1);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.GetSupplierOfPart("cpu") as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }
        [Test]
        public void TestControllerGetSupplierOfPartTestForInvalidInput()
        {
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.SupplierOfPart("Monitor")).Returns(supplier2);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.GetSupplierOfPart("Monitor") as ObjectResult;
            Assert.AreEqual(404, result.StatusCode);
        }
        [Test]
        public void TestControllerEditSupplierForValidInput()
        {
            var suppliers = new Supplier() { SID = "s1", SName = "Sourav", SEmail = "sourav@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 };
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.EditSupplier(suppliers)).Returns(true);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.EditSupplier(suppliers) as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }
        [Test]
        public void TestControllerEditSupplierForInValidInput()
        {
            var suppliers = new Supplier() { SID = "s5", SName = "Kaustab", SEmail = "kaustab@gmail.com", SMobile = 9124785630, SAddress = "Bangalor", Feedback = 6 };
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.EditSupplier(suppliers)).Returns(false);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.EditSupplier(suppliers) as ObjectResult;
            Assert.AreEqual(404, result.StatusCode);
        }
        [Test]
        public void TestControllerUpdateFeedback()
        {
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.UpdateFeedback(8,"s1")).Returns(true);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.UpdateFeedback(8, "s1") as ObjectResult;
            Assert.AreEqual(200, result.StatusCode);
        }
        [Test]
        public void TestControllerUpdateFeedbackForInvalidInput()
        {
            Mock<IServices> mock = new Mock<IServices>();
            mock.Setup(x => x.UpdateFeedback(8, "s1")).Returns(false);
            SuppliersController controller = new SuppliersController(mock.Object);
            ObjectResult? result = controller.UpdateFeedback(8, "s1") as ObjectResult;
            Assert.AreEqual(404, result.StatusCode);
        }
    }
}
