﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assert = NUnit.Framework.Assert;
using Moq;
using NUnit.Framework;
using SupplierMicroservice.Models;
using SupplierMicroservice.Services;
using Microsoft.EntityFrameworkCore;

namespace SupplierMicroserviceTest
{
    public class ConnectionFactory : IDisposable
    {
        private bool disposedValue=false;
        public SPContext CreateContextForInMemory()
        {
            var option = new DbContextOptionsBuilder<SPContext>().UseInMemoryDatabase(databaseName: "Test_Database").Options;

            var context = new SPContext(option);
            if (context != null)
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
            }

            return context;
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
    }
    [TestFixture]
    internal class ServicesTest
    {
        ConnectionFactory farctory = new ConnectionFactory();
        SPContext _context;
        [SetUp]
       public void SetUpMethod()
        {
            _context=farctory.CreateContextForInMemory();

            var supplier1 = new Supplier() { SID = "s1", SName = "Sourav", SEmail = "sourav@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5, PartsLink=null! };
            var supplier2 = new Supplier() { SID = "s2", SName = "Souvik", SEmail = "souvik@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 7, PartsLink = null! };
            _context.Add(supplier1);
            _context.Add(supplier2);

            var part1 = new Supplier_Part() { PID = "p1", PName = "CPU", PQuantity = 9, PDate = new DateTime(2022, 08, 31),SuppliersLink=null! };
            var part2 = new Supplier_Part() { PID = "p2", PName = "RAM", PQuantity = 7, PDate = new DateTime(2022, 09, 01), SuppliersLink = null! };
            _context.Add(part1);
            _context.Add(part2);
            var supplierPart1 = new SupplierPart() { SID = "s1", PID = "p1" };
            var supplierPart2 = new SupplierPart() { SID = "s2", PID = "p2" };
            var supplierPart3 = new SupplierPart() { SID = "s2", PID = "p1" };
            _context.Add(supplierPart1);
            _context.Add(supplierPart2);
            _context.Add(supplierPart3);
            _context.SaveChanges();
        }

        [Test]
        public void AddSupplierTestForValidInput()
        {
            var suppliers = new Supplier() { SID = "s3", SName = "Hrikdhiman", SEmail = "hrikdhiman@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 9 };
            var part = new Supplier_Part() { PID = "p3", PName = "SSD", PQuantity = 8, PDate = new DateTime(2022, 09, 05) };
            var supplierPart = new SupplierPart() { SID = "s3", PID = "p3", Supplier = suppliers, Supplier_Part = part };
            Services service = new Services(_context);
            Assert.AreEqual(true, service.AddSupplier(supplierPart));
        }
        [Test]
        public void AddSupplierTestForConflict()
        {
            var suppliers = new Supplier() { SID = "s1", SName = "Sourav", SEmail = "sourav@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 };
            var part = new Supplier_Part() { PID = "p3", PName = "SSD", PQuantity = 8, PDate = new DateTime(2022, 09, 05) };
            var supplierPart = new SupplierPart() { SID = "s1", PID = "p3", Supplier = suppliers, Supplier_Part = part };
            Services service = new Services(_context);
            Assert.AreEqual(false, service.AddSupplier(supplierPart));
        }
        [Test]
        public void AddSupplierTestForPresentPart()
        {
            var suppliers = new Supplier() { SID = "s4", SName = "Vamsi", SEmail = "vamsi@gmail.com", SMobile = 9124785630, SAddress = "Chennai", Feedback = 8 };
            var part = new Supplier_Part() { PID = "p2", PName = "RAM", PQuantity = 7, PDate = new DateTime(2022, 09, 01), SuppliersLink = null! };
            var supplierPart = new SupplierPart() { SID = "s4", PID = "p2", Supplier = suppliers, Supplier_Part = part };
            Services service = new Services(_context);
            Assert.AreEqual(true, service.AddSupplier(supplierPart));
        }
        [Test]
        public void AddSupplierTestForInValidEmail()
        {
            var suppliers = new Supplier() { SID = "s4", SName = "Vamsi", SEmail = "v", SMobile = 9124785630, SAddress = "Chennai", Feedback = 8 };
            var part = new Supplier_Part() { PID = "p2", PName = "RAM", PQuantity = 7, PDate = new DateTime(2022, 09, 01), SuppliersLink = null! };
            var supplierPart = new SupplierPart() { SID = "s4", PID = "p2", Supplier = suppliers, Supplier_Part = part };
            Services service = new Services(_context);
            Assert.AreEqual(false, service.AddSupplier(supplierPart));
        }
        [TestCase("",0)]
        //[TestCase("p3","CPU",0)]
        [TestCase("CPU", 2)]
        public void SupplierOfPartTestForValidInput(string pname, int result)
        {
           Services service = new Services(_context);
            var supplier= service.SupplierOfPart(pname).ToList();
            Assert.AreEqual(result, supplier.Count);
        }
        [Test]
        public void TestEditSupplierForValidInput()
        {
            var suppliers = new Supplier() { SID = "s1", SName = "Sourav", SEmail = "sourav@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 };
            Services service = new Services(_context);
            Assert.AreEqual(true, service.EditSupplier(suppliers));
        }
        [Test]
        public void TestEditSupplierForInValidEmail()
        {
            var suppliers = new Supplier() { SID = "s1", SName = "Sourav", SEmail = "s", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 };
            Services service = new Services(_context);
            Assert.AreEqual(false, service.EditSupplier(suppliers));
        }
        [Test]
        public void TestEditSupplierForInValidID()
        {
            var suppliers = new Supplier() { SID = "s0", SName = "Sourav", SEmail = "s", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 };
            Services service = new Services(_context);
            Assert.AreEqual(false, service.EditSupplier(suppliers));
        }
        [TestCase(8,"s1",true)]
        [TestCase(8,"s5",false)]
        [TestCase(15, "s5", false)]
        public void  TestUpdateFeedback(int feedback, string SupplierId,bool result)
        {
            Services service = new Services(_context);
            Assert.AreEqual(result, service.UpdateFeedback(feedback,SupplierId));
        }
        [Test]
        public void TestValidateSupplierDetailsForValidInput()
        {
            var suppliers = new Supplier() { SID = "s1", SName = "Sourav", SEmail = "sourav@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 };
            Services service = new Services(_context);
            Assert.AreEqual(true,service.ValidateSupplierDetails(suppliers));
        }
        [Test]
        public void TestValidateSupplierDetailsForInalidInput()
        {
            var suppliers = new Supplier() { SID = "s1", SName = "Sourav", SEmail = "sourav", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 };
            Services service = new Services(_context);
            Assert.AreEqual(false, service.ValidateSupplierDetails(suppliers));
        }
        [Test]
        public void TestAddSupplierForException()
        {
            var suppliers = new Supplier() { SID = "s3", SName = null!, SEmail = "hrikdhiman@gmail.com", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 9 };
            var part = new Supplier_Part() { PID = "p3", PName = "SSD", PQuantity = 8, PDate = new DateTime(2022, 09, 05) };
            var supplierPart = new SupplierPart() { SID = "s3", PID = "p3", Supplier = suppliers, Supplier_Part = part };
            Services service = new Services(_context);
            Assert.AreEqual(false, service.AddSupplier(supplierPart));
        }
        [Test]
        public void TestEditSupplierForException()
        {
            var suppliers = new Supplier() { SName = "Kaustab", SEmail = "kaustab@gmail.com", SMobile = 9124785630, SAddress = "Bangalor", Feedback = 6 };
            Services service = new Services(_context);
            Assert.AreEqual(false, service.EditSupplier(suppliers));
        }
        [Test]
        public void TestValidateSupplierDetailsForException()
        {
            var suppliers = new Supplier() { SID = "s1", SName = "Sourav", SMobile = 9124785630, SAddress = "Kolkata", Feedback = 5 };
            Services service = new Services(_context);
            Assert.AreEqual(false, service.ValidateSupplierDetails(suppliers));
        }
        [OneTimeTearDown]
        public void DisposeDb()
        {
            farctory.Dispose();
        }
    }
}
